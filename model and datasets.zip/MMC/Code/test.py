import math
import torch
import torch.utils.data.dataloader
from torch.utils.data import SubsetRandomSampler
import numpy as np
import pandas as pd  # 导入pandas库
from utils import *
from model import *
from config import *

if __name__ == '__main__':
    dataset = Dataset('test')
    # 计算要抽取的样本数量（40%）
    num_samples = math.ceil(len(dataset) * 0.5)  # 抽取
    indices = list(range(len(dataset)))  # 创建一个与数据集（dataset）中的元素数量相同的索引列表
    np.random.shuffle(indices)
    subset_indices = indices[:num_samples]

    sampler = SubsetRandomSampler(subset_indices)
    loader = data.DataLoader(dataset, batch_size=500, sampler=sampler, collate_fn=collate_fn)  # 随机20%测试集
    # loader = data.DataLoader(dataset, batch_size=500, collate_fn=collate_fn)
    # total_batches = math.ceil(len(dataset) / 500)  # 计算总批次数
    total_batches = math.ceil(num_samples / 500)  # 计算40%中的批次数
    results = []  # 用于保存每个模型的结果
    for i in range(300):

        with torch.no_grad():
            # model = torch.load(MODEL_DIR + 'model_{i}.pth', map_location=DEVICE)
            model = torch.load(f'./output/macbert_IDCNN_BiLSTM_CRF_AdamW_model/model_{i}.pth', map_location=DEVICE)
            y_true_list = []
            y_pred_list = []

            id2label, _ = get_label()

            for b, (input, target, mask) in enumerate(loader):
                input = input.to(DEVICE)
                target = target.to(DEVICE)
                mask = mask.to(DEVICE)
                y_pred = model(input, mask)
                loss = model.loss_fn(input, target, mask)

                print('>> batch:', b, 'loss:', loss.item())

                # # 拼接返回值
                # for lst in y_pred:
                # y_pred_list += lst
                # for y,m in zip(target, mask):
                # y_true_list += y[m==True].tolist()
                print(f'>> Processing batch {b + 1}/{total_batches}, loss: {loss.item()}')
                for lst in y_pred:
                    y_pred_list.append([id2label[i] for i in lst])
                for y, m in zip(target, mask):
                    y_true_list.append([id2label[i] for i in y[m == True].tolist()])
                # print(f'>> Processing batch {b + 1}/{total_batches},{report(y_true_list, y_pred_list)}')
            # print(report(y_true_list, y_pred_list))

            # # 整体准确率
            # y_true_tensor = torch.tensor(y_true_list)
            # y_pred_tensor = torch.tensor(y_pred_list)
            # accuracy = (y_true_tensor == y_pred_tensor).sum()/len(y_true_tensor)
            # print('>> total:', len(y_true_tensor), 'accuracy:', accuracy.item())
            print(f'{i}组数据为\n{report(y_true_list, y_pred_list)}')
            report_output = report(y_true_list, y_pred_list)
            # 解析字符串以提取评价指标
            lines = report_output.split('\n')
            for line in lines:
                if "micro avg" in line:
                    metrics = line.split()
                    micro_avg_precision = float(metrics[-4])
                    micro_avg_recall = float(metrics[-3])
                    micro_avg_f1 = float(metrics[-2])
                elif "macro avg" in line:
                    metrics = line.split()
                    macro_avg_precision = float(metrics[-4])
                    macro_avg_recall = float(metrics[-3])
                    macro_avg_f1 = float(metrics[-2])
                elif "weighted avg" in line:
                    metrics = line.split()
                    weighted_avg_precision = float(metrics[-4])
                    weighted_avg_recall = float(metrics[-3])
                    weighted_avg_f1 = float(metrics[-2])

            # 添加到结果列表
            results.append({
                'model_index': i,
                'micro_avg_precision': micro_avg_precision,
                'micro_avg_recall': micro_avg_recall,
                'micro_avg_f1': micro_avg_f1,
                'macro_avg_precision': macro_avg_precision,
                'macro_avg_recall': macro_avg_recall,
                'macro_avg_f1': macro_avg_f1,
                'weighted_avg_precision': weighted_avg_precision,
                'weighted_avg_recall': weighted_avg_recall,
                'weighted_avg_f1': weighted_avg_f1
            })

        # 将结果转换为DataFrame并保存为Excel文件
        df = pd.DataFrame(results)
        df.to_excel('model_results.xlsx', index=False)
