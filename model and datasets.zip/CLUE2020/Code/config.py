ORIGIN_DIR = './input/origin/'
ANNOTATION_DIR = './output/annotation/'

TRAIN_SAMPLE_PATH = './output/train_sample.txt'
TEST_SAMPLE_PATH = './output/test_sample.txt'

VOCAB_PATH = './output/vocab.txt'
LABEL_PATH = './output/label.txt'

WORD_PAD = '<PAD>'
WORD_UNK = '<UNK>'

WORD_PAD_ID = 0
WORD_UNK_ID = 1
LABEL_O_ID = 0
VOCAB_SIZE = 3000
EMBEDDING_DIM = 100
HIDDEN_SIZE = 512
TARGET_SIZE = 21
LR = 1e-5
EPOCH = 300
IDCNN_FILTERS = 64  # 在IDCNN层中使用的卷积滤波器的数量。每个滤波器将对输入进行一次卷积操作，以提取特征
IDCNN_KERNEL_SIZE = 3  # 在IDCNN层中使用的卷积核的大小。卷积核的大小决定了每次卷积操作覆盖的输入序列长度
IDCNN_BLOCKS = 4  # IDCNN层中堆叠的卷积块的数量。每个卷积块包含一系列卷积层和激活函数层，通过堆叠多个卷积块可以增加模型的感知野和表达能力
MODEL_DIR = 'output/macbert_IDCNN_BiLSTM_CRF_AdamW_model/'  # macbert模型
# MODEL_DIR = './output/model/'  # 初始base-bert-chinese模型

import torch

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
BERT_MODEL = 'C:/Users/Administrator/Jupyter Notebook/BERT_BiLSTM_CRF_NER/BERT/chinese-roberta-wwm-ext-large'
EMBEDDING_DIM = 1024
MAX_POSITION_EMBEDDINGS = 512
