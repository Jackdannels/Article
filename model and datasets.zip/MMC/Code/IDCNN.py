# cnn.py
import torch
import torch.nn as nn

class IDCNN(nn.Module):
    def __init__(self, input_dim, filters, kernel_size, num_blocks):
        super(IDCNN, self).__init__()
        self.layer1 = nn.Conv1d(input_dim, filters, kernel_size, padding=kernel_size // 2)
        self.layers = nn.ModuleList([
            nn.Conv1d(filters, filters, kernel_size, dilation=2**i, padding=2**i * (kernel_size // 2))
            for i in range(num_blocks)
        ])

    def forward(self, x):
        x = x.transpose(1, 2)  # 调整维度以匹配Conv1d的输入需求
        x = self.layer1(x)
        for layer in self.layers:
            x = torch.relu(x)
            x = layer(x)
        x = x.transpose(1, 2)  # 恢复维度以匹配后续处理
        return x
