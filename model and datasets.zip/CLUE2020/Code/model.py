import torch.nn as nn
from config import *
from torchcrf import CRF
import torch
from transformers import BertModel
from transformers import AutoTokenizer, AutoModelForMaskedLM
from transformers import DebertaV2Model  # 导入 DeBERTa-v3 模型
from IDCNN import IDCNN


class Model(nn.Module):
    def __init__(self):
        super().__init__()
        # self.embed = nn.Embedding(VOCAB_SIZE, EMBEDDING_DIM, WORD_PAD_ID)
        self.bert = BertModel.from_pretrained(BERT_MODEL)
        self.dropout = nn.Dropout(0.3)
        # 添加IDCNN层
        self.idcnn = IDCNN(EMBEDDING_DIM, IDCNN_FILTERS, IDCNN_KERNEL_SIZE, IDCNN_BLOCKS)
        self.lstm = nn.LSTM(
            input_size=IDCNN_FILTERS,  # 根据IDCNN的输出调整
            hidden_size=HIDDEN_SIZE,
            num_layers=1,  # 或更多层
            batch_first=True,
            bidirectional=True  # 指示LSTM应该是双向的
        )
        self.linear = nn.Linear(2 * HIDDEN_SIZE, TARGET_SIZE)  # 由于BiLSTM是双向的，所以是2倍的HIDDEN_SIZE
        self.crf = CRF(TARGET_SIZE, batch_first=True)

    def _get_lstm_feature(self, input, mask):
        out = self.bert(input, mask)[0]
        out = self.dropout(out)
        out = self.idcnn(out)  # IDCNN处理
        out, _ = self.lstm(out)  # BiLSTM处理
        return self.linear(out)

    def forward(self, input, mask):
        out = self._get_lstm_feature(input, mask)
        return self.crf.decode(out, mask)

    def loss_fn(self, input, target, mask):  # 损失函数计算
        y_pred = self._get_lstm_feature(input, mask)
        return -self.crf.forward(y_pred, target, mask, reduction='mean')

    def calculate_accuracy(self, y_pred, target):
        # 一个简单的准确率计算示例，适用于分类任务
        # 根据您的模型和任务类型进行调整
        _, predicted = torch.max(y_pred, 1)
        correct = (predicted == target).sum().item()
        return correct / target.size(0)


if __name__ == '__main__':
    model = Model()
    input = torch.randint(0, 3000, (100, 50))
    # print(model(input, None).shape)
    print(model)
    print(model(input, None))
    print(len(model(input, None)))
