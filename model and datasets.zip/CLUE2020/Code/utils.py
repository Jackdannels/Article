import torch
from torch.utils import data
from config import *
import pandas as pd
from seqeval.metrics import classification_report
from transformers import BertTokenizer
from transformers import logging
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from transformers import DebertaV2Model  # 导入 DeBERTa-v3 模型


def get_vocab():
    df = pd.read_csv(VOCAB_PATH, names=['word', 'id'])
    return list(df['word']), dict(df.values)


def get_label():
    df = pd.read_csv(LABEL_PATH, names=['label', 'id'])
    return list(df['label']), dict(df.values)


logging.set_verbosity_warning()


class Dataset(data.Dataset):

    def __init__(self, type='train', base_len=50):
        super().__init__()
        self.base_len = base_len
        sample_path = TRAIN_SAMPLE_PATH if type == 'train' else TEST_SAMPLE_PATH
        self.df = pd.read_csv(sample_path, names=['word', 'label'])
        _, self.word2id = get_vocab()
        _, self.label2id = get_label()
        self.get_points()
        # 初始化BERT
        # self.tokenizer = BertTokenizer.from_pretrained(BERT_MODEL)
        self.tokenizer = BertTokenizer.from_pretrained(BERT_MODEL)
        # self.tokenizer = DebertaV2Tokenizer.from_pretrained('microsoft/deberta-v3-xlarge')  # 使用 DeBERTa-v3 分词器

    def get_points(self):  # 计算分割点
        self.points = [0]
        i = 0
        while True:
            if i + self.base_len >= len(self.df):
                self.points.append(len(self.df))
                break
            if self.df.loc[i + self.base_len, 'label'] == 'O':
                i += self.base_len
                self.points.append(i)
            else:
                i += 1

    def __len__(self):
        return len(self.points) - 1

    def __getitem__(self, index):
        df = self.df[self.points[index]:self.points[index + 1]]
        word_unk_id = self.word2id[WORD_UNK]
        label_o_id = self.label2id['O']
        # input = [self.word2id.get(w, word_unk_id) for w in df['word']]
        target = [self.label2id.get(l, label_o_id) for l in df['label']]
        # 文本转id
        # 注意：先自己将句子做分词，再转id，避免bert自动分词导致句子长度变化
        input = self.tokenizer.encode(list(df['word']), add_special_tokens=False)  # list是为了将英文拆分，防止句子长度发生变化
        # bert要求句子长度不能超过512
        # return input, target
        return input[:MAX_POSITION_EMBEDDINGS], target[:MAX_POSITION_EMBEDDINGS]


def collate_fn(batch):  # 校验函数是为了长度统一
    batch.sort(key=lambda x: len(x[0]), reverse=True)
    max_len = len(batch[0][0])
    input = []
    target = []
    mask = []
    for item in batch:
        pad_len = max_len - len(item[0])
        input.append(item[0] + [WORD_PAD_ID] * pad_len)
        target.append(item[1] + [LABEL_O_ID] * pad_len)
        mask.append([1] * len(item[0]) + [0] * pad_len)
    return torch.tensor(input), torch.tensor(target), torch.tensor(mask).bool()  # bool是CRF的要求


def extract(label, text):
    i = 0
    res = []
    while i < len(label):
        if label[i] != 'O':
            prefix, name = label[i].split('-')
            start = end = i
            i += 1
            while i < len(label) and label[i] == 'I-' + name:
                end = i
                i += 1
            res.append([name, text[start:end + 1]])
        else:
            i += 1
    return res


def report(y_true, y_pred):
    return classification_report(y_true, y_pred, digits=4)


if __name__ == '__main__':
    dataset = Dataset()
    loader = data.DataLoader(dataset, batch_size=100, collate_fn=collate_fn)  # collate_fn检验函数
    for batch in loader:
        print(batch)  # 处理批次数据
