from datetime import timedelta
import os
import torch
from torch.optim.lr_scheduler import CosineAnnealingLR
from utils import *
from model import *
from config import *
import time
from seqeval.metrics import f1_score, precision_score, recall_score
from torch.optim.lr_scheduler import OneCycleLR
from torch.optim import AdamW  # 修改这里导入AdamW
from torch.optim import Adam

print(torch.cuda.is_available())
print(DEVICE)
CHECKPOINT_PATH = 'path_to_checkpoint.pth'

def save_checkpoint(state, filename=CHECKPOINT_PATH):
    torch.save(state, filename)


def load_checkpoint():
    if os.path.isfile(CHECKPOINT_PATH):
        print("Loading checkpoint...")
        checkpoint = torch.load(CHECKPOINT_PATH)
        model.load_state_dict(checkpoint['model_state'])
        optimizer.load_state_dict(checkpoint['optimizer_state'])
        scheduler.load_state_dict(checkpoint['scheduler_state'])
        start_epoch = checkpoint['epoch']
        return start_epoch
    else:
        return 0


if __name__ == '__main__':
    dataset = Dataset()
    loader = data.DataLoader(
        dataset,
        batch_size=50,
        shuffle=True,
        collate_fn=collate_fn,
    )
    # print(len(dataset))
    # exit()
    model = Model().to(DEVICE)
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
    scheduler = CosineAnnealingLR(optimizer, T_max=EPOCH)  # 例如使用余弦退火调度器
    total_steps = len(loader) * EPOCH
    # scheduler = OneCycleLR(optimizer, max_lr=0.0001, total_steps=total_steps)
    start_time = time.time()  # 记录整个训练过程的开始时间
    total_batches = len(loader) * EPOCH  # 计算总的batch数量
    start_epoch = load_checkpoint()
    for e in range(start_epoch, EPOCH):
        for b, (input, target, mask) in enumerate(loader):

            input = input.to(DEVICE)
            mask = mask.to(DEVICE)
            target = target.to(DEVICE)
            y_pred = model(input, mask)
            loss = model.loss_fn(input, target, mask)
            optimizer.zero_grad()  # 梯度清零
            loss.backward()  # 反向传播
            optimizer.step()  # 步进
            # scheduler.step()  # 更新学习率OneCycleLR专属
            if b % 100 == 0:
                current_time = time.time()
                elapsed_time = current_time - start_time
                batches_done = e * len(loader) + b + 1  # 加1以确保不为零
                total_batches_left = total_batches - batches_done
                if batches_done > 0:
                    avg_time_per_batch = elapsed_time / batches_done
                    est_time_left = total_batches_left * avg_time_per_batch
                    epoch_progress = (e + b / len(loader))  # 正确计算epoch的进度
                    # 格式化为时分秒
                    formatted_time_left = str(timedelta(seconds=int(est_time_left)))
                    print(
                        f'>> epoch: {epoch_progress:.2f}, loss: {loss.item()}, estimated time left: {formatted_time_left}')

        scheduler.step()
        save_checkpoint({
            'epoch': e + 1,
            'model_state': model.state_dict(),
            'optimizer_state': optimizer.state_dict(),
            'scheduler_state': scheduler.state_dict(),
        })

        torch.save(model, MODEL_DIR + f'model_{e}.pth')
